# Barracks Frontend
This is the frontend for BarracksMedia powered by Next.js.